create definer = root@`%` view myv6 as
select `myemployees`.`employees`.`last_name` AS `last_name`,
       `myemployees`.`employees`.`email`     AS `email`,
       `myemployees`.`employees`.`salary`    AS `salary`
from `myemployees`.`employees`
where `myemployees`.`employees`.`employee_id` in (select `myemployees`.`employees`.`manager_id`
                                                  from `myemployees`.`employees`
                                                  where (`myemployees`.`employees`.`manager_id` is not null));

