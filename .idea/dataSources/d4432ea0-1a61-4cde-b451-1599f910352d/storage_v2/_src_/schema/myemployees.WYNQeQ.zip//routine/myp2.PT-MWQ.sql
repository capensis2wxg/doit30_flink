create
    definer = root@`%` procedure myp2(IN beautyName varchar(20))
begin
    select bo.* from girls.boys bo
    right join girls.beauty b on bo.id = b.boyfriend_id
    where b.name = beautyName;
end;

