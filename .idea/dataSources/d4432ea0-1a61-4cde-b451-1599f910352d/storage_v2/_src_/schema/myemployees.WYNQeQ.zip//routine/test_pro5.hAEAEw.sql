create
    definer = root@`%` procedure test_pro5(IN beautyName varchar(20), OUT str varchar(50))
begin
#     set str = '';
    select concat(beautyName, ' and ', ifnull(boyName, 'null')) into str
    from girls.boys bo
    right outer join girls.beauty b on b.boyfriend_id = bo.id
    where b.name = beautyName;
end;

