create
    definer = root@`%` procedure myInOut(INOUT a int, INOUT b int)
begin
    set a = a * 2;
    set b = b * 2;
end;

