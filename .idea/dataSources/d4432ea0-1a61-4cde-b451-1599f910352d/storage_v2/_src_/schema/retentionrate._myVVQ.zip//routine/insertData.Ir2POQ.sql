create
    definer = root@`%` procedure insertData()
begin
    declare count int default 0;
    while count < 1000  DO
         set @day = FLOOR(Rand() * 10 + 1);
         set @deId = Floor(RAND() * 8 + 1);
         set @appId = Floor(RAND() * 5 + 1);
         set @log_day = STR_TO_DATE(CONCAT('2019-01-', @day), '%Y-%m-%d');
         insert into user_log values (@log_day ,@deId, @appId);
         set count = count + 1;
        end while;
end;

